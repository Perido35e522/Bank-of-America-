const express = require('express');
const cors = require('cors');
const app = express();

app.use(express.json());
app.use(cors());

const users = {
    'Cote de Pablo': '353522'
};

app.post('/login', (req, res) => {
    const { username, password } = req.body;
    if (users[username] === password) {
        res.json({ success: true });
    } else {
        res.json({ success: false });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));
