function downloadStatement() {
    alert("Downloading bank statement...");
}

function logout() {
    alert("You have been logged out.");
}
